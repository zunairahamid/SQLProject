create table Agent(AgentID number(4,0),
AgentName varchar2(14),
TransNo number(4,0),
username varchar2(30),
password varchar2(30),
constraint pk_Agent primary key(AgentID),
constraint tra_age_fk foreign key(TransNo) references Transaction(TransNo)
);
commit;