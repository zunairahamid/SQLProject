    create table Transaction(TransNo number(4,0),
    TransTime TIMESTAMP,
    TransDate date,
    CusNo number(4,0),
    constraint pk_Transaction primary key(TransNo),
    constraint tra_cus_fk foreign key(CusNo) references CustomerTrip(CustNo)
    );
    commit;