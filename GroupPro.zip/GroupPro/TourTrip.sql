create table TourTrip(TripNo number(4,0),
StartTime TIMESTAMP,
TripDate date,
Price number(4,0),
DurationTrip TIMESTAMP,
StartLocation varchar2(14),
TPno number(4,0),
TGno number(4,0),
constraint pk_Trip primary key(TripNo),
constraint tri_gui_no foreign key(TGNo) references TourGuide(TGNo),
constraint tri_pac_no foreign key(TPno) references TourPackage(TPNo)
);
commit;