create Table CustomerTrip(CustNo number(4,0), 
CustName varchar(14), 
RegistrationDate date, 
constraint pk_Customer primary key(CustNo)
);
commit;