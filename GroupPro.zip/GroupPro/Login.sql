create table Login(LogNo number(4,0),
AgentID number(4,0),
    LTime time,
    LDate date,
    CompletionStatus varchar2(14),
    constraint pk_Login primary key(LogNo),
    constraint log_age_fk foreign key(AgentID) references Agent(AgentID)
    );
    commit;