create Table Languages(TGNo number(4,0),
LanguageGuide varchar2(14),
constraint pk_Language primary key(LanguageGuide),
constraint la_tg_fk foreign key(TGNo) references TourGuide(TGNo)
);
commit;