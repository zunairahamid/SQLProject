create Table Reserves(CustNo number(4,0),
TTNo number(4,0),
RStatus varchar2(14),
PickUp varchar2(14),
constraint res_cus_fk foreign key(CustNo) references CustomerTrip(CustNo),
constraint res_tri_fk foreign key(TTNo) references TourTrip(TTNo)
);
commit;