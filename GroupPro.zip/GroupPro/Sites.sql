create Table Sites(TTNo number(4,0),
Sname varchar2(14),
DescriptionSite varchar2(100),
NLandmark varchar2(34),
constraint pk_Sites primary key(Sname),
constraint sa_tt_fk foreign key(TTNo) references TourTrip(TripNo)
);
commit;