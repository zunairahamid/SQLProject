create Table TourPackage(TPNo number(4,0),
TPname varchar2(14),
Nourishment varchar2(14),
Transportation varchar2(14),
constraint tp_Language primary key(TPNo)
);
commit;