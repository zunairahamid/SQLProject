create Table TourGuide(TGNo number(4,0),
TGname varchar2(14),
constraint pk_TGuide primary key(TGNo)
);
commit;